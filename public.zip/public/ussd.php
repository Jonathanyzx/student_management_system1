<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\Services\UssdService;

// Get USSD parameters
$sessionId = $_POST['sessionId'] ?? '';
$serviceCode = $_POST['serviceCode'] ?? '';
$phoneNumber = $_POST['phoneNumber'] ?? '';
$text = $_POST['text'] ?? '';

// Initialize USSD service
$ussdService = new UssdService();

// Process USSD request
$response = $ussdService->handleRequest($sessionId, $serviceCode, $phoneNumber, $text);

// Return response
header('Content-Type: text/plain');
echo $response; 