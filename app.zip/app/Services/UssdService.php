<?php
namespace App\Services;

use App\Config\Database;
use Exception;

class UssdService {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    private function verifyPin($regNumber, $pin) {
        try {
            $student = $this->db->select('students', ['registration_number = ?', 'pin = ?'], [$regNumber, $pin]);
            return !empty($student);
        } catch (\PDOException $e) {
            error_log("PIN Verification Error: " . $e->getMessage());
            return false;
        }
    }

    private function getStudentByPhone($phoneNumber) {
        try {
            $student = $this->db->select('students', ['phone_number = ?'], [$phoneNumber]);
            return !empty($student) ? $student[0] : null;
        } catch (\PDOException $e) {
            error_log("Student Lookup Error: " . $e->getMessage());
            return null;
        }
    }

    private function getParentByPhone($phoneNumber) {
        try {
            $parent = $this->db->select('parents', ['phone_number = ?'], [$phoneNumber]);
            return !empty($parent) ? $parent[0] : null;
        } catch (\PDOException $e) {
            error_log("Parent Lookup Error: " . $e->getMessage());
            return null;
        }
    }

    private function getParentStudents($parentId) {
        try {
            return $this->db->query(
                "SELECT s.*, ps.relationship 
                 FROM parent_students ps 
                 JOIN students s ON ps.student_id = s.id 
                 WHERE ps.parent_id = ?",
                [$parentId]
            )->fetchAll();
        } catch (\PDOException $e) {
            error_log("Parent Students Error: " . $e->getMessage());
            return [];
        }
    }

    private function createNotification($studentId, $parentId, $type, $message) {
        try {
            $data = [
                'student_id' => $studentId,
                'parent_id' => $parentId,
                'type' => $type,
                'message' => $message
            ];
            $this->db->insert('notifications', $data);
        } catch (\PDOException $e) {
            error_log("Notification Error: " . $e->getMessage());
        }
    }

    private function checkLowAttendance($studentId, $parentId) {
        try {
            $attendance = $this->db->query(
                "SELECT COUNT(*) as total, 
                        SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent 
                 FROM attendance 
                 WHERE student_id = ? 
                 AND date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)",
                [$studentId]
            )->fetch();

            if ($attendance['total'] > 0 && ($attendance['absent'] / $attendance['total']) > 0.3) {
                $this->createNotification(
                    $studentId,
                    $parentId,
                    'Attendance',
                    "Warning: Your child has missed more than 30% of classes in the last 30 days"
                );
            }
        } catch (\PDOException $e) {
            error_log("Attendance Check Error: " . $e->getMessage());
        }
    }

    private function getRoleMenu($role) {
        $response = "CON Welcome to Student Management System\n";
        switch ($role) {
            case 'Student':
                $response .= "1. View Attendance\n";
                $response .= "2. View Exam Results\n";
                $response .= "3. View Payment Records\n";
                break;
            case 'Parent':
                $response .= "1. View Student Attendance\n";
                $response .= "2. View Student Exam Results\n";
                $response .= "3. View Student Payment Records\n";
                break;
            case 'Teacher':
                $response .= "1. Mark Attendance\n";
                $response .= "2. View Assigned Courses\n";
                break;
            case 'Admin':
                $response .= "1. Manage Teachers\n";
                $response .= "2. Manage Students\n";
                $response .= "3. Process Teacher Salary\n";
                break;
            default:
                $response .= "1. Register Student\n";
                $response .= "2. Register Parent\n";
                $response .= "3. Register Teacher\n";
                $response .= "4. Register Admin\n";
        }
        return $response;
    }

    public function process($phoneNumber, $text) {
        $parts = explode('*', $text);
        $response = "";

        // Check if user is already registered and get their role
        $user = $this->getUserByPhone($phoneNumber);
        if ($user) {
            $response = $this->getRoleMenu($user['role']);
        } else {
            // Default menu for unregistered users
            $response = $this->getRoleMenu(null);
        }

        return $response;
    }

    public function handleRequest($sessionId, $serviceCode, $phoneNumber, $text) {
        $response = "";
        
        // Validate required parameters
        if (empty($sessionId) || empty($serviceCode) || empty($phoneNumber)) {
            return "END Invalid request parameters";
        }

        // Clean phone number (remove + if present)
        $phoneNumber = ltrim($phoneNumber, '+');
        
        if (empty($text)) {
            // First request - show main menu
            $response = "CON Welcome to Student Management System\n";
            $response .= "1. Register Student\n";
            $response .= "2. Check Attendance\n";
            $response .= "3. View Results\n";
            $response .= "4. Course Enrollment\n";
            $response .= "5. Fee Payment\n";
            $response .= "6. Parent Portal\n";
            $response .= "7. Register Parent\n";
            $response .= "8. Teacher Portal\n";
            $response .= "9. Admin Portal";
        } 
        // Student Registration
        elseif ($text == "1") {
            $response = "CON Enter your full name";
        }
        elseif (preg_match('/^1\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 2) {
                $response = "CON Enter your registration number";
            } elseif (count($parts) == 3) {
                $response = "CON Enter a 4-digit PIN";
            } elseif (count($parts) == 4) {
                $name = $parts[1];
                $regNumber = $parts[2];
                $pin = $parts[3];
                
                // Validate PIN format
                if (!preg_match('/^\d{4}$/', $pin)) {
                    return "END PIN must be 4 digits";
                }
                
                try {
                    // Check if registration number exists
                    $existingStudent = $this->db->select('students', ['registration_number = ?'], [$regNumber]);
                    if (!empty($existingStudent)) {
                        return "END Registration number already exists";
                    }
                    
                    $data = [
                        'phone_number' => $phoneNumber,
                        'name' => $name,
                        'registration_number' => $regNumber,
                        'pin' => $pin
                    ];
                    
                    $this->db->insert('students', $data);
                    $response = "END Registration successful!\nName: {$name}\nReg No: {$regNumber}";
                } catch (\PDOException $e) {
                    error_log("Registration Error: " . $e->getMessage());
                    $response = "END Registration failed. Please try again.";
                }
            }
        }
        // Parent Registration
        elseif ($text == "7") {
            $response = "CON Enter your full name";
        }
        elseif (preg_match('/^7\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 2) {
                $response = "CON Enter a 4-digit PIN";
            } elseif (count($parts) == 3) {
                $name = $parts[1];
                $pin = $parts[2];
                
                // Validate PIN format
                if (!preg_match('/^\d{4}$/', $pin)) {
                    return "END PIN must be 4 digits";
                }
                
                try {
                    $data = [
                        'phone_number' => $phoneNumber,
                        'name' => $name,
                        'pin' => $pin
                    ];
                    
                    $this->db->insert('parents', $data);
                    $response = "END Parent registration successful!\nName: {$name}";
                } catch (\PDOException $e) {
                    error_log("Parent Registration Error: " . $e->getMessage());
                    $response = "END Registration failed. Please try again.";
                }
            }
        }
        // Parent Portal
        elseif ($text == "6") {
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                if (empty($students)) {
                    $response = "CON No students linked to your account.\n";
                    $response .= "1. Link to Student\n";
                    $response .= "2. Register New Student";
                } else {
                    $response = "CON Select student:\n";
                    foreach ($students as $index => $student) {
                        $response .= ($index + 1) . ". {$student['name']} ({$student['relationship']})\n";
                    }
                    $response .= ($index + 2) . ". Link to New Student";
                }
            } else {
                $response = "END Parent not found.\nPlease register first (Option 7).";
            }
        }
        // Parent Portal - Link to Student
        elseif (preg_match('/^6\*[1-9][0-9]*$/', $text)) {
            $parts = explode('*', $text);
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                $selectedIndex = intval($parts[1]) - 1;
                
                if (empty($students) && $selectedIndex == 0) {
                    $response = "CON Enter student registration number (e.g., ST001)";
                } elseif (!empty($students) && $selectedIndex == count($students)) {
                    $response = "CON Enter student registration number (e.g., ST001)";
                } else {
                    if ($selectedIndex >= 0 && $selectedIndex < count($students)) {
                        $selectedStudent = $students[$selectedIndex];
                        $response = "CON {$selectedStudent['name']}\n";
                        $response .= "1. View Results\n";
                        $response .= "2. View Attendance\n";
                        $response .= "3. View Fee Payments\n";
                        $response .= "4. View Enrolled Courses";
                    } else {
                        $response = "END Invalid selection";
                    }
                }
            } else {
                $response = "END Parent not found. Please register first (Option 7).";
            }
        }
        // Parent Portal - Link Student Process
        elseif (preg_match('/^6\*[1-9][0-9]*\*[A-Za-z0-9]+\*[1-3]$/', $text)) {
            $parts = explode('*', $text);
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                $selectedIndex = intval($parts[1]) - 1;
                
                if ((empty($students) && $selectedIndex == 0) || (!empty($students) && $selectedIndex == count($students))) {
                    $regNumber = trim($parts[2]);
                    $relationshipChoice = $parts[3];
                    
                    $relationships = [
                        '1' => 'Father',
                        '2' => 'Mother',
                        '3' => 'Guardian'
                    ];
                    
                    try {
                        $student = $this->db->select('students', ['registration_number = ?'], [$regNumber]);
                        if (empty($student)) {
                            $response = "END Student not found. Please check the registration number and try again.";
                        } else {
                            // Check if already linked
                            $existingLink = $this->db->select('parent_students', 
                                ['parent_id = ?', 'student_id = ?'], 
                                [$parent['id'], $student[0]['id']]
                            );
                            
                            if (!empty($existingLink)) {
                                $response = "END Student is already linked to your account";
                            } else {
                                $link = [
                                    'parent_id' => $parent['id'],
                                    'student_id' => $student[0]['id'],
                                    'relationship' => $relationships[$relationshipChoice]
                                ];
                                
                                $this->db->insert('parent_students', $link);
                                $response = "END Successfully linked to student!\n";
                                $response .= "Name: {$student[0]['name']}\n";
                                $response .= "Relationship: {$relationships[$relationshipChoice]}";
                            }
                        }
                    } catch (\PDOException $e) {
                        error_log("Student Link Error: " . $e->getMessage());
                        $response = "END Error linking student. Please try again.";
                    }
                } else {
                    $response = "END Invalid selection";
                }
            } else {
                $response = "END Parent not found. Please register first (Option 7).";
            }
        }
        // Parent Portal - View Results
        elseif (preg_match('/^6\*[1-9][0-9]*\*1$/', $text)) {
            $parts = explode('*', $text);
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                $selectedIndex = intval($parts[1]) - 1;
                
                if ($selectedIndex >= 0 && $selectedIndex < count($students)) {
                    $selectedStudent = $students[$selectedIndex];
                    try {
                        $results = $this->db->query(
                            "SELECT c.name as course_name, er.score, er.exam_date 
                             FROM exam_results er 
                             JOIN courses c ON er.course_id = c.id 
                             WHERE er.student_id = ? 
                             ORDER BY er.exam_date DESC 
                             LIMIT 5",
                            [$selectedStudent['id']]
                        )->fetchAll();
                        
                        if (empty($results)) {
                            $response = "END No exam results found for {$selectedStudent['name']}";
                        } else {
                            $response = "END Results for {$selectedStudent['name']}:\n";
                            foreach ($results as $result) {
                                $response .= "{$result['course_name']}: {$result['score']}\n";
                            }
                        }
                    } catch (\PDOException $e) {
                        error_log("Results Error: " . $e->getMessage());
                        $response = "END Error fetching results";
                    }
                }
            }
        }
        // Parent Portal - View Attendance
        elseif (preg_match('/^6\*[1-9][0-9]*\*2$/', $text)) {
            $parts = explode('*', $text);
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                $selectedIndex = intval($parts[1]) - 1;
                
                if ($selectedIndex >= 0 && $selectedIndex < count($students)) {
                    $selectedStudent = $students[$selectedIndex];
                    try {
                        $attendance = $this->db->query(
                            "SELECT date, status 
                             FROM attendance 
                             WHERE student_id = ? 
                             ORDER BY date DESC 
                             LIMIT 5",
                            [$selectedStudent['id']]
                        )->fetchAll();
                        
                        if (empty($attendance)) {
                            $response = "END No attendance records found for {$selectedStudent['name']}";
                        } else {
                            $response = "END Attendance for {$selectedStudent['name']}:\n";
                            foreach ($attendance as $record) {
                                $response .= date('d/m/Y', strtotime($record['date'])) . ": {$record['status']}\n";
                            }
                        }
                    } catch (\PDOException $e) {
                        error_log("Attendance Error: " . $e->getMessage());
                        $response = "END Error fetching attendance";
                    }
                }
            }
        }
        // Parent Portal - View Fee Payments
        elseif (preg_match('/^6\*[1-9][0-9]*\*3$/', $text)) {
            $parts = explode('*', $text);
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                $selectedIndex = intval($parts[1]) - 1;
                
                if ($selectedIndex >= 0 && $selectedIndex < count($students)) {
                    $selectedStudent = $students[$selectedIndex];
                    try {
                        $payments = $this->db->query(
                            "SELECT amount, payment_date, reference_number 
                             FROM fee_payments 
                             WHERE student_id = ? 
                             ORDER BY payment_date DESC 
                             LIMIT 5",
                            [$selectedStudent['id']]
                        )->fetchAll();
                        
                        if (empty($payments)) {
                            $response = "END No payment records found for {$selectedStudent['name']}";
                        } else {
                            $response = "END Payments for {$selectedStudent['name']}:\n";
                            foreach ($payments as $payment) {
                                $response .= date('d/m/Y', strtotime($payment['payment_date'])) . ": {$payment['amount']} (Ref: {$payment['reference_number']})\n";
                            }
                        }
                    } catch (\PDOException $e) {
                        error_log("Payments Error: " . $e->getMessage());
                        $response = "END Error fetching payments";
                    }
                }
            }
        }
        // Parent Portal - View Enrolled Courses
        elseif (preg_match('/^6\*[1-9][0-9]*\*4$/', $text)) {
            $parts = explode('*', $text);
            $parent = $this->getParentByPhone($phoneNumber);
            if ($parent) {
                $students = $this->getParentStudents($parent['id']);
                $selectedIndex = intval($parts[1]) - 1;
                
                if ($selectedIndex >= 0 && $selectedIndex < count($students)) {
                    $selectedStudent = $students[$selectedIndex];
                    try {
                        $courses = $this->db->query(
                            "SELECT c.name, sc.enrollment_date, sc.status 
                             FROM student_courses sc 
                             JOIN courses c ON sc.course_id = c.id 
                             WHERE sc.student_id = ? 
                             ORDER BY sc.enrollment_date DESC",
                            [$selectedStudent['id']]
                        )->fetchAll();
                        
                        if (empty($courses)) {
                            $response = "END No enrolled courses found for {$selectedStudent['name']}";
                        } else {
                            $response = "END Courses for {$selectedStudent['name']}:\n";
                            foreach ($courses as $course) {
                                $response .= "{$course['name']} ({$course['status']})\n";
                            }
                        }
                    } catch (\PDOException $e) {
                        error_log("Courses Error: " . $e->getMessage());
                        $response = "END Error fetching courses";
                    }
                }
            }
        }
        // Attendance checking
        elseif ($text == "2") {
            $response = "CON Enter your registration number";
        }
        elseif (preg_match('/^2\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 2) {
                $regNumber = $parts[1];
                try {
                    $student = $this->db->select('students', ['registration_number = ?', 'phone_number = ?'], [$regNumber, $phoneNumber]);
                    if (empty($student)) {
                        $response = "END Student not found or phone number mismatch";
                    } else {
                        $studentId = $student[0]['id'];
                        $attendance = $this->db->select('attendance', 
                            ['student_id = ?', 'date = ?'], 
                            [$studentId, date('Y-m-d')]
                        );
                        
                        if (empty($attendance)) {
                            $response = "END No attendance record for today";
                        } else {
                            $status = $attendance[0]['status'];
                            $response = "END Your attendance for today: {$status}";
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Attendance Check Error: " . $e->getMessage());
                    $response = "END Error checking attendance";
                }
            }
        }
        // Exam results
        elseif ($text == "3") {
            $response = "CON Enter your registration number";
        }
        elseif (preg_match('/^3\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 2) {
                $regNumber = $parts[1];
                try {
                    $student = $this->db->select('students', ['registration_number = ?', 'phone_number = ?'], [$regNumber, $phoneNumber]);
                    if (empty($student)) {
                        $response = "END Student not found or phone number mismatch";
                    } else {
                        $studentId = $student[0]['id'];
                        $results = $this->db->query(
                            "SELECT c.name as course_name, er.score, er.exam_date 
                             FROM exam_results er 
                             JOIN courses c ON er.course_id = c.id 
                             WHERE er.student_id = ? 
                             ORDER BY er.exam_date DESC 
                             LIMIT 5",
                            [$studentId]
                        )->fetchAll();
                        
                        if (empty($results)) {
                            $response = "END No exam results found";
                        } else {
                            $response = "END Your recent results:\n";
                            foreach ($results as $result) {
                                $response .= "{$result['course_name']}: {$result['score']}\n";
                            }
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Results Check Error: " . $e->getMessage());
                    $response = "END Error checking results";
                }
            }
        }
        // Course enrollment
        elseif ($text == "4") {
            $response = "CON Enter your registration number";
        }
        elseif (preg_match('/^4\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 2) {
                $response = "CON Enter your PIN";
            } elseif (count($parts) == 3) {
                $regNumber = $parts[1];
                $pin = $parts[2];
                
                try {
                    $student = $this->db->select('students', ['registration_number = ?', 'phone_number = ?', 'pin = ?'], [$regNumber, $phoneNumber, $pin]);
                    if (empty($student)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        try {
                            $courses = $this->db->select('courses');
                            if (empty($courses)) {
                                $response = "END No courses available";
                            } else {
                                $response = "CON Available courses:\n";
                                foreach ($courses as $index => $course) {
                                    $response .= ($index + 1) . ". {$course['name']}\n";
                                }
                            }
                        } catch (\PDOException $e) {
                            error_log("Course List Error: " . $e->getMessage());
                            $response = "END Error fetching courses";
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Authentication Error: " . $e->getMessage());
                    $response = "END Error verifying credentials";
                }
            } elseif (count($parts) == 4) {
                $regNumber = $parts[1];
                $pin = $parts[2];
                $courseChoice = $parts[3];
                
                try {
                    $student = $this->db->select('students', ['registration_number = ?', 'phone_number = ?', 'pin = ?'], [$regNumber, $phoneNumber, $pin]);
                    if (empty($student)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        try {
                            $courses = $this->db->select('courses');
                            
                            if ($courseChoice > 0 && $courseChoice <= count($courses)) {
                                $courseId = $courses[$courseChoice - 1]['id'];
                                $studentId = $student[0]['id'];
                                
                                // Check if already enrolled
                                $existingEnrollment = $this->db->select('student_courses', 
                                    ['student_id = ?', 'course_id = ?'], 
                                    [$studentId, $courseId]
                                );
                                
                                if (!empty($existingEnrollment)) {
                                    $response = "END You are already enrolled in this course";
                                } else {
                                    $enrollment = [
                                        'student_id' => $studentId,
                                        'course_id' => $courseId,
                                        'enrollment_date' => date('Y-m-d'),
                                        'status' => 'Active'
                                    ];
                                    
                                    $this->db->insert('student_courses', $enrollment);
                                    $response = "END Successfully enrolled in {$courses[$courseChoice - 1]['name']}";
                                }
                            } else {
                                $response = "END Invalid course selection";
                            }
                        } catch (\PDOException $e) {
                            error_log("Enrollment Error: " . $e->getMessage());
                            $response = "END Error enrolling in course";
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Authentication Error: " . $e->getMessage());
                    $response = "END Error verifying credentials";
                }
            }
        }
        // Fee payment
        elseif ($text == "5") {
            $response = "CON Enter your registration number";
        }
        elseif (preg_match('/^5\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 2) {
                $response = "CON Enter your PIN";
            } elseif (count($parts) == 3) {
                $regNumber = $parts[1];
                $pin = $parts[2];
                
                try {
                    $student = $this->db->select('students', ['registration_number = ?', 'phone_number = ?', 'pin = ?'], [$regNumber, $phoneNumber, $pin]);
                    if (empty($student)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        $response = "CON Enter amount to pay";
                    }
                } catch (\PDOException $e) {
                    error_log("Authentication Error: " . $e->getMessage());
                    $response = "END Error verifying credentials";
                }
            } elseif (count($parts) == 4) {
                $regNumber = $parts[1];
                $pin = $parts[2];
                $amount = $parts[3];
                
                // Validate amount
                if (!is_numeric($amount) || $amount <= 0) {
                    return "END Invalid amount. Please enter a positive number";
                }
                
                try {
                    $student = $this->db->select('students', ['registration_number = ?', 'phone_number = ?', 'pin = ?'], [$regNumber, $phoneNumber, $pin]);
                    if (empty($student)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        try {
                            $studentId = $student[0]['id'];
                            
                            $payment = [
                                'student_id' => $studentId,
                                'amount' => $amount,
                                'payment_date' => date('Y-m-d'),
                                'payment_method' => 'USSD',
                                'reference_number' => uniqid('PAY')
                            ];
                            
                            $this->db->insert('fee_payments', $payment);
                            $response = "END Payment successful!\nAmount: {$amount}\nRef: {$payment['reference_number']}";
                        } catch (\PDOException $e) {
                            error_log("Payment Error: " . $e->getMessage());
                            $response = "END Error processing payment";
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Authentication Error: " . $e->getMessage());
                    $response = "END Error verifying credentials";
                }
            }
        }
        // Teacher Portal
        elseif ($text == "8") {
            $response = "CON Teacher Portal\n";
            $response .= "1. Register Teacher\n";
            $response .= "2. Mark Attendance\n";
            $response .= "3. View Assigned Courses";
        }
        // Teacher Registration
        elseif ($text == "8*1") {
            $response = "CON Enter your full name";
        }
        elseif (preg_match('/^8\*1\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 3) {
                $response = "CON Enter your teacher ID";
            } elseif (count($parts) == 4) {
                $response = "CON Enter a 4-digit PIN";
            } elseif (count($parts) == 5) {
                $name = $parts[2];
                $teacherId = $parts[3];
                $pin = $parts[4];
                
                // Validate PIN format
                if (!preg_match('/^\d{4}$/', $pin)) {
                    return "END PIN must be 4 digits";
                }
                
                try {
                    // Check if teacher ID exists
                    $existingTeacher = $this->db->select('teachers', ['teacher_id = ?'], [$teacherId]);
                    if (!empty($existingTeacher)) {
                        return "END Teacher ID already exists";
                    }
                    
                    $data = [
                        'phone_number' => $phoneNumber,
                        'name' => $name,
                        'teacher_id' => $teacherId,
                        'pin' => $pin
                    ];
                    
                    $this->db->insert('teachers', $data);
                    $response = "END Teacher registration successful!\nName: {$name}\nTeacher ID: {$teacherId}";
                } catch (\PDOException $e) {
                    error_log("Teacher Registration Error: " . $e->getMessage());
                    $response = "END Registration failed. Please try again.";
                }
            }
        }
        // Teacher Attendance
        elseif ($text == "8*2") {
            $response = "CON Enter your teacher ID";
        }
        elseif (preg_match('/^8\*2\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 3) {
                $response = "CON Enter your PIN";
            } elseif (count($parts) == 4) {
                $teacherId = $parts[2];
                $pin = $parts[3];
                
                try {
                    $teacher = $this->db->select('teachers', ['teacher_id = ?', 'phone_number = ?', 'pin = ?'], [$teacherId, $phoneNumber, $pin]);
                    if (empty($teacher)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        $teacherId = $teacher[0]['id'];
                        $attendance = [
                            'teacher_id' => $teacherId,
                            'date' => date('Y-m-d'),
                            'status' => 'Present'
                        ];
                        
                        $this->db->insert('teacher_attendance', $attendance);
                        $response = "END Attendance marked successfully!";
                    }
                } catch (\PDOException $e) {
                    error_log("Teacher Attendance Error: " . $e->getMessage());
                    $response = "END Error marking attendance";
                }
            }
        }
        // Teacher Courses
        elseif ($text == "8*3") {
            $response = "CON Enter your teacher ID";
        }
        elseif (preg_match('/^8\*3\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 3) {
                $response = "CON Enter your PIN";
            } elseif (count($parts) == 4) {
                $teacherId = $parts[2];
                $pin = $parts[3];
                
                try {
                    $teacher = $this->db->select('teachers', ['teacher_id = ?', 'phone_number = ?', 'pin = ?'], [$teacherId, $phoneNumber, $pin]);
                    if (empty($teacher)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        $teacherId = $teacher[0]['id'];
                        $courses = $this->db->query(
                            "SELECT c.name, c.code, tc.academic_year, tc.semester 
                             FROM teacher_courses tc 
                             JOIN courses c ON tc.course_id = c.id 
                             WHERE tc.teacher_id = ? 
                             ORDER BY tc.academic_year DESC, tc.semester",
                            [$teacherId]
                        )->fetchAll();
                        
                        if (empty($courses)) {
                            $response = "END No courses assigned to you";
                        } else {
                            $response = "END Your assigned courses:\n";
                            foreach ($courses as $course) {
                                $response .= "{$course['name']} ({$course['code']})\n";
                                $response .= "Year: {$course['academic_year']}, Semester: {$course['semester']}\n\n";
                            }
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Teacher Courses Error: " . $e->getMessage());
                    $response = "END Error fetching course assignments";
                }
            }
        }
        // Admin Portal
        elseif ($text == "9") {
            $response = "CON Admin Portal\n";
            $response .= "1. Register Admin\n";
            $response .= "2. View System Reports\n";
            $response .= "3. Manage Teachers\n";
            $response .= "4. Manage Students";
        }
        // Admin Registration
        elseif ($text == "9*1") {
            $response = "CON Enter your full name";
        }
        elseif (preg_match('/^9\*1\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 3) {
                $response = "CON Enter your admin ID";
            } elseif (count($parts) == 4) {
                $response = "CON Enter a 4-digit PIN";
            } elseif (count($parts) == 5) {
                $name = $parts[2];
                $adminId = $parts[3];
                $pin = $parts[4];
                
                // Validate PIN format
                if (!preg_match('/^\d{4}$/', $pin)) {
                    return "END PIN must be 4 digits";
                }
                
                try {
                    // Check if admin ID exists
                    $existingAdmin = $this->db->select('administrators', ['admin_id = ?'], [$adminId]);
                    if (!empty($existingAdmin)) {
                        return "END Admin ID already exists";
                    }
                    
                    $data = [
                        'phone_number' => $phoneNumber,
                        'name' => $name,
                        'admin_id' => $adminId,
                        'pin' => $pin,
                        'role' => 'Admin'
                    ];
                    
                    $this->db->insert('administrators', $data);
                    $response = "END Admin registration successful!\nName: {$name}\nAdmin ID: {$adminId}";
                } catch (\PDOException $e) {
                    error_log("Admin Registration Error: " . $e->getMessage());
                    $response = "END Registration failed. Please try again.";
                }
            }
        }
        // Admin Reports
        elseif ($text == "9*2") {
            $response = "CON Enter your admin ID";
        }
        elseif (preg_match('/^9\*2\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 3) {
                $response = "CON Enter your PIN";
            } elseif (count($parts) == 4) {
                $adminId = $parts[2];
                $pin = $parts[3];
                
                try {
                    $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?', 'pin = ?'], [$adminId, $phoneNumber, $pin]);
                    if (empty($admin)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        // Get system statistics
                        $stats = $this->db->query(
                            "SELECT 
                                (SELECT COUNT(*) FROM students) as total_students,
                                (SELECT COUNT(*) FROM teachers) as total_teachers,
                                (SELECT COUNT(*) FROM courses) as total_courses,
                                (SELECT COUNT(*) FROM fee_payments WHERE payment_date = CURDATE()) as today_payments"
                        )->fetch();
                        
                        $response = "END System Report:\n";
                        $response .= "Total Students: {$stats['total_students']}\n";
                        $response .= "Total Teachers: {$stats['total_teachers']}\n";
                        $response .= "Total Courses: {$stats['total_courses']}\n";
                        $response .= "Today's Payments: {$stats['today_payments']}";
                    }
                } catch (\PDOException $e) {
                    error_log("Admin Reports Error: " . $e->getMessage());
                    $response = "END Error generating report";
                }
            }
        }
        // Admin Portal - Teacher Management
        elseif ($text == "9*3") {
            $response = "CON Teacher Management:\n";
            $response .= "1. View All Teachers\n";
            $response .= "2. Assign Course to Teacher\n";
            $response .= "3. View Teacher Courses";
        }
        // Admin - View All Teachers
        elseif ($text == "9*3*1") {
            $response = "CON Enter your admin ID";
        }
        elseif (preg_match('/^9\*3\*1\*[A-Za-z0-9]+$/', $text)) {
            $parts = explode('*', $text);
            $adminId = $parts[3];
            
            try {
                $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?'], [$adminId, $phoneNumber]);
                if (empty($admin)) {
                    $response = "END Invalid credentials or phone number mismatch";
                } else {
                    $teachers = $this->db->select('teachers');
                    if (empty($teachers)) {
                        $response = "END No teachers found";
                    } else {
                        $response = "END Teacher List:\n";
                        foreach ($teachers as $teacher) {
                            $response .= "Name: {$teacher['name']}\n";
                            $response .= "ID: {$teacher['teacher_id']}\n";
                            $response .= "Department: {$teacher['department']}\n\n";
                        }
                    }
                }
            } catch (\PDOException $e) {
                error_log("Teacher List Error: " . $e->getMessage());
                $response = "END Error fetching teacher list";
            }
        }
        // Admin - Assign Course to Teacher
        elseif ($text == "9*3*2") {
            $response = "CON Enter your admin ID";
        }
        elseif (preg_match('/^9\*3\*2\*[A-Za-z0-9]+$/', $text)) {
            $parts = explode('*', $text);
            $adminId = $parts[3];
            
            try {
                $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?'], [$adminId, $phoneNumber]);
                if (empty($admin)) {
                    $response = "END Invalid credentials or phone number mismatch";
                } else {
                    $response = "CON Enter teacher ID";
                }
            } catch (\PDOException $e) {
                error_log("Teacher Assignment Error: " . $e->getMessage());
                $response = "END Error accessing teacher assignment";
            }
        }
        // Admin - Select Course for Teacher
        elseif (preg_match('/^9\*3\*2\*[A-Za-z0-9]+\*[A-Za-z0-9]+$/', $text)) {
            $parts = explode('*', $text);
            $adminId = $parts[3];
            $teacherId = $parts[4];
            
            try {
                $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?'], [$adminId, $phoneNumber]);
                if (empty($admin)) {
                    $response = "END Invalid credentials or phone number mismatch";
                } else {
                    $teacher = $this->db->select('teachers', ['teacher_id = ?'], [$teacherId]);
                    if (empty($teacher)) {
                        $response = "END Teacher not found";
                    } else {
                        $courses = $this->db->select('courses');
                        if (empty($courses)) {
                            $response = "END No courses available";
                        } else {
                            $response = "CON Select course:\n";
                            foreach ($courses as $index => $course) {
                                $response .= ($index + 1) . ". {$course['name']} ({$course['code']})\n";
                            }
                        }
                    }
                }
            } catch (\PDOException $e) {
                error_log("Course Selection Error: " . $e->getMessage());
                $response = "END Error fetching courses";
            }
        }
        // Admin - Complete Course Assignment
        elseif (preg_match('/^9\*3\*2\*[A-Za-z0-9]+\*[A-Za-z0-9]+\*[1-9][0-9]*$/', $text)) {
            $parts = explode('*', $text);
            $adminId = $parts[3];
            $teacherId = $parts[4];
            $courseChoice = intval($parts[5]) - 1;
            
            try {
                $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?'], [$adminId, $phoneNumber]);
                if (empty($admin)) {
                    $response = "END Invalid credentials or phone number mismatch";
                } else {
                    $teacher = $this->db->select('teachers', ['teacher_id = ?'], [$teacherId]);
                    if (empty($teacher)) {
                        $response = "END Teacher not found";
                    } else {
                        $courses = $this->db->select('courses');
                        if ($courseChoice >= 0 && $courseChoice < count($courses)) {
                            $courseId = $courses[$courseChoice]['id'];
                            $teacherId = $teacher[0]['id'];
                            
                            // Check if already assigned
                            $existingAssignment = $this->db->select('teacher_courses', 
                                ['teacher_id = ?', 'course_id = ?'], 
                                [$teacherId, $courseId]
                            );
                            
                            if (!empty($existingAssignment)) {
                                $response = "END Course already assigned to this teacher";
                            } else {
                                $assignment = [
                                    'teacher_id' => $teacherId,
                                    'course_id' => $courseId,
                                    'academic_year' => date('Y'),
                                    'semester' => '1' // Default to first semester
                                ];
                                
                                $this->db->insert('teacher_courses', $assignment);
                                $response = "END Course assigned successfully!\n";
                                $response .= "Teacher: {$teacher[0]['name']}\n";
                                $response .= "Course: {$courses[$courseChoice]['name']}";
                            }
                        } else {
                            $response = "END Invalid course selection";
                        }
                    }
                }
            } catch (\PDOException $e) {
                error_log("Course Assignment Error: " . $e->getMessage());
                $response = "END Error assigning course";
            }
        }
        // Admin - View Teacher Courses
        elseif ($text == "9*3*3") {
            $response = "CON Enter your admin ID";
        }
        elseif (preg_match('/^9\*3\*3\*[A-Za-z0-9]+$/', $text)) {
            $parts = explode('*', $text);
            $adminId = $parts[3];
            
            try {
                $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?'], [$adminId, $phoneNumber]);
                if (empty($admin)) {
                    $response = "END Invalid credentials or phone number mismatch";
                } else {
                    $response = "CON Enter teacher ID";
                }
            } catch (\PDOException $e) {
                error_log("Teacher Courses View Error: " . $e->getMessage());
                $response = "END Error accessing teacher courses";
            }
        }
        // Admin - Display Teacher Courses
        elseif (preg_match('/^9\*3\*3\*[A-Za-z0-9]+\*[A-Za-z0-9]+$/', $text)) {
            $parts = explode('*', $text);
            $adminId = $parts[3];
            $teacherId = $parts[4];
            
            try {
                $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?'], [$adminId, $phoneNumber]);
                if (empty($admin)) {
                    $response = "END Invalid credentials or phone number mismatch";
                } else {
                    $teacher = $this->db->select('teachers', ['teacher_id = ?'], [$teacherId]);
                    if (empty($teacher)) {
                        $response = "END Teacher not found";
                    } else {
                        $courses = $this->db->query(
                            "SELECT c.name, c.code, tc.academic_year, tc.semester 
                             FROM teacher_courses tc 
                             JOIN courses c ON tc.course_id = c.id 
                             WHERE tc.teacher_id = ? 
                             ORDER BY tc.academic_year DESC, tc.semester",
                            [$teacher[0]['id']]
                        )->fetchAll();
                        
                        if (empty($courses)) {
                            $response = "END No courses assigned to this teacher";
                        } else {
                            $response = "END Courses for {$teacher[0]['name']}:\n";
                            foreach ($courses as $course) {
                                $response .= "{$course['name']} ({$course['code']})\n";
                                $response .= "Year: {$course['academic_year']}, Semester: {$course['semester']}\n\n";
                            }
                        }
                    }
                }
            } catch (\PDOException $e) {
                error_log("Teacher Courses Display Error: " . $e->getMessage());
                $response = "END Error fetching teacher courses";
            }
        }
        // Admin Student Management
        elseif ($text == "9*4") {
            $response = "CON Enter your admin ID";
        }
        elseif (preg_match('/^9\*4\*/', $text)) {
            $parts = explode('*', $text);
            if (count($parts) == 3) {
                $response = "CON Enter your PIN";
            } elseif (count($parts) == 4) {
                $adminId = $parts[2];
                $pin = $parts[3];
                
                try {
                    $admin = $this->db->select('administrators', ['admin_id = ?', 'phone_number = ?', 'pin = ?'], [$adminId, $phoneNumber, $pin]);
                    if (empty($admin)) {
                        $response = "END Invalid credentials or phone number mismatch";
                    } else {
                        $students = $this->db->select('students');
                        if (empty($students)) {
                            $response = "END No students found";
                        } else {
                            $response = "CON Student List:\n";
                            foreach ($students as $index => $student) {
                                $response .= ($index + 1) . ". {$student['name']} ({$student['registration_number']})\n";
                            }
                        }
                    }
                } catch (\PDOException $e) {
                    error_log("Admin Student Management Error: " . $e->getMessage());
                    $response = "END Error fetching student list";
                }
            }
        }
        // Admin - Manage Teacher Salary
        elseif ($text == "9*3*4") {
            $response = "CON Salary Management:\n";
            $response .= "1. View Teacher Salary\n";
            $response .= "2. Process Salary Payment";
        }
        // Admin - View Teacher Salary
        elseif ($text == "9*3*4*1") {
            $response = "CON Enter teacher ID";
        }
        // Admin - Process Salary Payment
        elseif ($text == "9*3*4*2") {
            $response = "CON Enter teacher ID";
        }
        // Admin - View Teacher Salary with ID
        elseif (preg_match('/^9\*3\*4\*1\*[1-9][0-9]*$/', $text)) {
            $parts = explode('*', $text);
            $teacherId = $parts[4];
            
            try {
                $teacher = $this->db->select('teachers', ['id = ?'], [$teacherId]);
                if (empty($teacher)) {
                    $response = "END Teacher not found";
                } else {
                    $salary = $this->db->query(
                        "SELECT amount, payment_date, reference_number, status 
                         FROM teacher_payments 
                         WHERE teacher_id = ? 
                         ORDER BY payment_date DESC 
                         LIMIT 5",
                        [$teacherId]
                    )->fetchAll();
                    
                    if (empty($salary)) {
                        $response = "END No salary records found for {$teacher[0]['name']}";
                    } else {
                        $response = "END Salary History for {$teacher[0]['name']}:\n";
                        foreach ($salary as $payment) {
                            $response .= "Date: " . date('d/m/Y', strtotime($payment['payment_date'])) . "\n";
                            $response .= "Amount: " . number_format($payment['amount']) . " RWF\n";
                            $response .= "Status: {$payment['status']}\n";
                            $response .= "Ref: {$payment['reference_number']}\n\n";
                        }
                    }
                }
            } catch (\PDOException $e) {
                error_log("Salary View Error: " . $e->getMessage());
                $response = "END Error fetching salary records";
            }
        }
        // Admin - Process Salary Payment with ID
        elseif (preg_match('/^9\*3\*4\*2\*[1-9][0-9]*$/', $text)) {
            $parts = explode('*', $text);
            $teacherId = $parts[4];
            
            try {
                $teacher = $this->db->select('teachers', ['id = ?'], [$teacherId]);
                if (empty($teacher)) {
                    $response = "END Teacher not found";
                } else {
                    $response = "CON Enter salary amount (e.g., 50000)";
                }
            } catch (\PDOException $e) {
                error_log("Salary Process Error: " . $e->getMessage());
                $response = "END Error processing salary. Please try again.";
            }
        }
        // Admin - Complete Salary Payment
        elseif (preg_match('/^9\*3\*4\*2\*[1-9][0-9]*\*[0-9]+$/', $text)) {
            $parts = explode('*', $text);
            $teacherId = $parts[4];
            $amount = $parts[5];
            
            try {
                error_log("Starting salary payment process for teacher ID: " . $teacherId);
                
                // Verify teacher exists
                $teacher = $this->db->select('teachers', ['id = ?'], [$teacherId]);
                error_log("Teacher query result: " . print_r($teacher, true));
                
                if (empty($teacher)) {
                    error_log("Teacher not found with ID: " . $teacherId);
                    return "END Teacher not found. Please check the teacher ID.";
                }

                // Validate amount
                if (!is_numeric($amount) || $amount <= 0) {
                    error_log("Invalid amount entered: " . $amount);
                    return "END Invalid amount. Please enter a positive number.";
                }

                // Generate reference number
                $referenceNumber = 'SAL' . date('Ymd') . rand(100, 999);
                error_log("Generated reference number: " . $referenceNumber);

                // Insert payment record
                $payment = [
                    'teacher_id' => $teacherId,
                    'amount' => $amount,
                    'payment_date' => date('Y-m-d'),
                    'payment_method' => 'USSD',
                    'reference_number' => $referenceNumber,
                    'status' => 'Paid'
                ];
                error_log("Payment data to insert: " . print_r($payment, true));

                $result = $this->db->insert('teacher_payments', $payment);
                error_log("Insert result: " . ($result ? "true" : "false"));

                if ($result) {
                    error_log("Payment processed successfully");
                    return "END Salary payment processed successfully!\n" .
                           "Teacher: " . $teacher[0]['name'] . "\n" .
                           "Amount: " . number_format($amount) . " RWF\n" .
                           "Reference: " . $referenceNumber;
                } else {
                    error_log("Failed to insert payment record");
                    return "END Failed to process salary payment. Please try again.";
                }
            } catch(\Exception $e) {
                error_log("Salary payment error: " . $e->getMessage());
                error_log("Error trace: " . $e->getTraceAsString());
                return "END Error processing salary payment. Please try again.";
            }
        }
        
        return $response;
    }

    private function getUserByPhone($phoneNumber) {
        try {
            $user = $this->db->select('users', ['phone_number = ?'], [$phoneNumber]);
            return !empty($user) ? $user[0] : null;
        } catch (Exception $e) {
            error_log("User Lookup Error: " . $e->getMessage());
            return null;
        }
    }
} 