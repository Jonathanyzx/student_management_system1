<?php
namespace App\Config;

class Database {
    private $host = 'localhost';
    private $db_name = 'students_management';
    private $username = 'root';
    private $password = '';
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new \PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        } catch(\PDOException $e) {
            error_log("Connection Error: " . $e->getMessage());
        }

        return $this->conn;
    }

    public function select($table, $conditions = [], $params = []) {
        try {
            $conn = $this->getConnection();
            $sql = "SELECT * FROM " . $table;
            
            if (!empty($conditions)) {
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch(\PDOException $e) {
            error_log("Select Error: " . $e->getMessage());
            return [];
        }
    }

    public function insert($table, $data) {
        try {
            $conn = $this->getConnection();
            $columns = implode(", ", array_keys($data));
            $values = implode(", ", array_fill(0, count($data), "?"));
            
            $sql = "INSERT INTO " . $table . " (" . $columns . ") VALUES (" . $values . ")";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute(array_values($data));
            
            return $conn->lastInsertId();
        } catch(\PDOException $e) {
            error_log("Insert Error: " . $e->getMessage());
            throw $e;
        }
    }

    public function query($sql, $params = []) {
        try {
            $conn = $this->getConnection();
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch(\PDOException $e) {
            error_log("Query Error: " . $e->getMessage());
            throw $e;
        }
    }
} 