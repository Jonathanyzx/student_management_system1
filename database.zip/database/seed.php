<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\Config\Database;

try {
    $db = new Database();

    // Sample courses
    $courses = [
        ['code' => 'MATH101', 'name' => 'Mathematics'],
        ['code' => 'ENG101', 'name' => 'English'],
        ['code' => 'SCI101', 'name' => 'Science'],
        ['code' => 'HIST101', 'name' => 'History']
    ];

    foreach ($courses as $course) {
        $db->insert('courses', $course);
    }

    // Sample student
    $student = [
        'phone_number' => '1234567890',
        'name' => 'John Doe',
        'registration_number' => 'ST001',
        'pin' => '1234'
    ];

    $studentId = $db->insert('students', $student);

    // Sample attendance
    $attendance = [
        'student_id' => $studentId,
        'date' => date('Y-m-d'),
        'status' => 'Present'
    ];

    $db->insert('attendance', $attendance);

    // Sample exam results
    $courseIds = $db->select('courses');
    foreach ($courseIds as $course) {
        $result = [
            'student_id' => $studentId,
            'course_id' => $course['id'],
            'score' => rand(60, 100),
            'exam_date' => date('Y-m-d', strtotime('-1 week'))
        ];
        $db->insert('exam_results', $result);
    }

    // First, verify the teacher exists
    $teacher = $db->select('teachers', ['id = ?'], [1]);
    
    if (!empty($teacher)) {
        // Insert test salary payment
        $payment = [
            'teacher_id' => $teacher[0]['id'],
            'amount' => 50000,
            'payment_date' => date('Y-m-d'),
            'payment_method' => 'USSD',
            'reference_number' => 'SAL' . date('Ymd') . '001',
            'status' => 'Paid'
        ];

        $result = $db->insert('teacher_payments', $payment);

        if ($result) {
            echo "Test salary payment inserted successfully!\n";
        } else {
            echo "Failed to insert test payment.\n";
        }
    } else {
        echo "Teacher not found. Please register a teacher first.\n";
    }

    echo "Database seeded successfully!\n";
} catch(\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
} 