-- Insert sample courses
INSERT INTO courses (code, name, description) VALUES
('MATH101', 'Mathematics', 'Basic Mathematics Course'),
('ENG101', 'English', 'English Language Course'),
('SCI101', 'Science', 'General Science Course'),
('HIS101', 'History', 'World History Course');

-- Insert sample students
INSERT INTO students (phone_number, name, registration_number, pin) VALUES
('254700000001', 'John Doe', 'REG001', '1234'),
('254700000002', 'Jane Smith', 'REG002', '5678'),
('254700000003', 'Mike Johnson', 'REG003', '9012');

-- Insert sample parents
INSERT INTO parents (phone_number, name, pin) VALUES
('254700000004', 'Robert Doe', '4321'),
('254700000005', 'Mary Smith', '8765');

-- Link parents to students
INSERT INTO parent_students (parent_id, student_id, relationship) VALUES
(1, 1, 'Father'),
(2, 2, 'Mother');

-- Insert sample attendance
INSERT INTO attendance (student_id, date, status) VALUES
(1, '2024-01-01', 'Present'),
(1, '2024-01-02', 'Present'),
(1, '2024-01-03', 'Absent'),
(2, '2024-01-01', 'Present'),
(2, '2024-01-02', 'Present'),
(2, '2024-01-03', 'Present');

-- Insert sample exam results
INSERT INTO exam_results (student_id, course_id, score, exam_date) VALUES
(1, 1, 85.5, '2024-01-15'),
(1, 2, 78.0, '2024-01-15'),
(2, 1, 92.0, '2024-01-15'),
(2, 2, 88.5, '2024-01-15');

-- Insert sample course enrollments
INSERT INTO student_courses (student_id, course_id, enrollment_date, status) VALUES
(1, 1, '2024-01-01', 'Active'),
(1, 2, '2024-01-01', 'Active'),
(2, 1, '2024-01-01', 'Active'),
(2, 2, '2024-01-01', 'Active');

-- Insert sample fee payments
INSERT INTO fee_payments (student_id, amount, payment_date, payment_method, reference_number) VALUES
(1, 5000.00, '2024-01-01', 'USSD', 'PAY001'),
(1, 3000.00, '2024-01-15', 'USSD', 'PAY002'),
(2, 5000.00, '2024-01-01', 'USSD', 'PAY003'); 